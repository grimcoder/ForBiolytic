﻿using System.ComponentModel;

namespace ForBiolytic
{
    public interface IDataContext : INotifyPropertyChanged
    {
    }
}